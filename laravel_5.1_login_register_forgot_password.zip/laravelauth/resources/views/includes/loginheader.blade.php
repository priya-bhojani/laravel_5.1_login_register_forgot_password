<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/simple-line-icons/simple-line-icons.min.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/plugins/uniform/css/uniform.default.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/css/style-crm.css') }}" rel="stylesheet" type="text/css"/>

<link href="{{ URL::asset('assets/css/style-responsive.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/css/plugins.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/css/themes/default.css') }} " rel="stylesheet" type="text/css" id="style_color"/>
<link href="{{ URL::asset('assets/css/pages/login.css') }} " rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('assets/css/custom.css') }}" rel="stylesheet" type="text/css"/>
<!-- BEGIN BODY -->
<body class="login">
